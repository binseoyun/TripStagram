package com.example.myapplication

import android.graphics.drawable.Drawable

data class ListViewModel (
    val text:String,
    //이미지 추가
    var img : Int
    )